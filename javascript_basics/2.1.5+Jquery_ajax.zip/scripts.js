$('#country_flag').attr('src','./assets/flag.png' )
$('.card-title').text('Select Flag')

$('.dropdown-item').click(function(){
    let country_code = $(this).data('country')

    /* 
    Example with img url

    let country_name = $(this).text()
    let end_point = `https://flagsapi.com/${country_code}/shiny/64.png`

    $('#country_flag').attr('src',end_point)
    $('.card-title').text(country_name)
    this is bad practice
    */ 

    //example with API
    $.ajax({
        url: `https://restcountries.com/v3.1/alpha/${country_code}`,
        type: 'GET',
        dataType: 'json',
        success: function(data){
            console.log(data)
            let flag = data[0].flags.svg; // get flag URL from API
            $('#country_flag').attr('src', flag)
            $('.card-title').text(data[0].name.common)
            
        },
        error: function(){
            $('#country_flag').attr('src','./assets/flag_not_found.jpg')
            $('.card-title').text('Flag not found')
        }
    }) 
})