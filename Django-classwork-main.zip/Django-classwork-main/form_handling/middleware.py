import time

#Middleware for logging, example code
#Function-based middleware to log request processing time

# def request_timing_middleware(get_response):
#     def middleware(request):
        

#         return response
#     return middleware