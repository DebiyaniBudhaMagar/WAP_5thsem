from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt

def Register(request):
    return render(request, 'register.html')

def Login(request):
    return render(request, 'login.html')

def Logout(request):
    return redirect('login')


def Home(request):
    return render(request, 'home.html')

def Error(request):
    return render(request, 'error.html')
    
def Send_data(request):
    return HttpResponse('Data received')

def Send_json_response(request):
    data = {
    }
    return JsonResponse(data)
